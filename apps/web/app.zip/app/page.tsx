"use client";

import { useEffect, useState } from "react";

export default function Home() {
  const [data, setData] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadDashboard();
  }, []);

  async function loadDashboard() {
    try {
      const res = await fetch("http://localhost:3000/dashboard/overview", {
        headers: {
          "x-client-id": "11111111-1111-1111-1111-111111111111",
        },
      });

      if (!res.ok) {
        const text = await res.text();
        throw new Error(`HTTP ${res.status}: ${text}`);
      }

      const json = await res.json();
      setData(json);
      setError(null);
    } catch (err: any) {
      console.error(err);
      setError(err.message);
    }
  }

  async function handleTopAction() {
    if (!data?.topAction) return;

    const action = data.topAction.action;

    if (action?.kind === "navigate") {
      alert(`Navegar para: ${action.screen}`);
      return;
    }

    if (action?.kind === "api") {
      try {
        const res = await fetch(`http://localhost:3000${action.path}`, {
          method: action.method ?? "POST",
          headers: {
            "Content-Type": "application/json",
            "x-client-id": "11111111-1111-1111-1111-111111111111",
          },
        });

        if (!res.ok) {
          const text = await res.text();
          throw new Error(`HTTP ${res.status}: ${text}`);
        }

        const result = await res.json();
        alert(result.toast ?? "Ação executada com sucesso.");

        await loadDashboard();
      } catch (err: any) {
        console.error(err);
        alert(`Erro ao executar ação: ${err.message}`);
      }

      return;
    }

    alert("Ação não configurada.");
  }

  if (error) {
    return <div className="p-10 text-red-600">Erro: {error}</div>;
  }

  if (!data) {
    return <div className="p-10">Carregando...</div>;
  }

  return (
    <div className="p-10 space-y-6">
      <h1 className="text-2xl font-bold">Finance Copilot</h1>

      <div className="bg-green-100 p-6 rounded-xl shadow">
        <h2 className="text-lg text-gray-600">{data.ui.hero.title}</h2>
        <p className="text-3xl font-bold">{data.ui.hero.headline}</p>
        <p className="text-gray-500">{data.ui.hero.subtitle}</p>
      </div>

      <div className="bg-white p-6 rounded-xl shadow border">
        <p className="text-gray-500">Score</p>
        <p className="text-3xl font-bold">{data.score.value}</p>
        <p className="text-gray-500">{data.score.label}</p>
      </div>

      <div className="bg-blue-100 p-6 rounded-xl shadow">
        <p className="text-gray-600">{data.ui.highlightCard.title}</p>
        <p className="text-2xl font-bold">{data.ui.highlightCard.value}</p>
        <p className="text-gray-500">{data.ui.highlightCard.subtitle}</p>
      </div>

      {data.topAction && (
        <div className="bg-white p-6 rounded-xl shadow border">
          <p className="text-gray-500 mb-2">Próxima melhor ação</p>
          <p className="text-2xl font-bold">{data.topAction.label}</p>

          {data.topAction.impactLabel && (
            <p className="text-green-700 mt-2">{data.topAction.impactLabel}</p>
          )}

          {data.topAction.monthlySavingsFormatted && (
            <p className="text-gray-600 mt-1">
              Economia: {data.topAction.monthlySavingsFormatted}/mês
            </p>
          )}

          {data.topAction.performance && (
            <div className="mt-4 text-sm text-gray-600">
              <p>Taxa de sucesso: {data.topAction.performance.successRate}%</p>
              <p>
                Resultado já comprovado:{" "}
                {data.topAction.performance.actualSavingsFormatted}
              </p>
            </div>
          )}

          <button
            onClick={handleTopAction}
            className="mt-4 px-4 py-2 rounded-lg bg-black text-white"
          >
            {data.topAction.ctaLabel}
          </button>
        </div>
      )}
    </div>
  );
}